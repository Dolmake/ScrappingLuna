

function BikeManager() {
    
}