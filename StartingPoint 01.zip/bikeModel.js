//Main JS

function BikeManager(){

    this.initialize = function() {
        //TODO: load the Model
    }

    this.getStationById = function(stationId){
        //TODO: return the proper station
    }
}